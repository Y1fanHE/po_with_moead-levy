mkdir ./images
python pop_by_gen.py
python traj_distrib.py
python traj_by_gen.py
