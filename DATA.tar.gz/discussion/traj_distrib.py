import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


def get_data(gen, alg):
    dat = pd.read_csv(f"./trial_len/{alg}.csv", header=None)
    dat.columns = ["Generation","Length","Update"]
    dat = dat[dat["Generation"]==gen]
    dat = dat[dat["Length"]!=0]
    dat1 = list(dat[dat["Update"]==1]["Length"])
    dat2 = list(dat[dat["Update"]==2]["Length"])
    dat = dat1 + dat2 + dat2
    return dat

gens = [0,1,2,3,4,5,10]

styles = ["paper"]
# set algorithm names, labels, markers and colors
algs = ["levy", "unif", "norm", "const"]
labs = ["LEVY", "UNIF", "NORM", "CONST"]
maks = ["o", "v", "^", "s"]
cols = ["b", "g", "r", "c"]

for style in styles:
    # set seaborn style
    sns.set(style, "white", "bright", font_scale=1.2,
            rc={'font.family': ['sans-serif'],
                'font.sans-serif': ['Arial',
                                    'DejaVu Sans',
                                    'Liberation Sans',
                                    'Bitstream Vera Sans',
                                    'sans-serif'],
                'axes.edgecolor': '.0',
                'axes.labelcolor': '.0',
                'text.color': '.0',
                'xtick.bottom': True,
                'xtick.color': '.0',
                'xtick.direction': 'in',
                'xtick.top': True,
                'xtick.major.size': 3,
                'ytick.color': '.0',
                'ytick.direction': 'in',
                'ytick.left': True,
                'ytick.right': True,
                'ytick.major.size': 3,})

    fig = plt.figure(figsize=(6, 4))
    for gen in gens:
        dats = []
        for alg in algs:
            dat = get_data(gen, alg)
            dats.append(dat)
        plt.hist(dats, bins=7, range=[0, 1.4], label=labs, color=cols)
        plt.xlabel("Length of Successful Trials")
        plt.ylabel("Frequency (logarithm scale)")
        plt.ylim(1,1000)
        plt.yscale("log")
        plt.legend(frameon=True,
                   loc = "upper right",
                   edgecolor="black",
                   fancybox=False)
        plt.savefig("./images/len_distr_{}_{}.eps".format(gen, style))
        plt.clf()
        
                
