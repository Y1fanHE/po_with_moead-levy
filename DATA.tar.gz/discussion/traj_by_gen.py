import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def get_count(gen):
    dat = pd.read_csv(f"./trial_len/lvxm.csv", header=None)
    dat.columns = ["Generation","Length","Update"]
    dat = dat[dat["Generation"]==gen]
    dat = dat[dat["Length"]>=0.2]
    dat1 = len(list(dat[dat["Update"]==1]["Length"]))
    dat2 = len(list(dat[dat["Update"]==2]["Length"]))
    count = dat1 + 2 * dat2
    return count

dat = pd.read_csv(f"./trial_len/lvxm.csv", header=None)
gens = int(len(dat)/100)
counts = [0] * 1500
for gen in range(gens):
    counts[gen] = get_count(gen)

styles = ["paper"]
for style in styles:
    # set seaborn style
    sns.set(style, "white", "bright", font_scale=1.2,
            rc={'font.family': ['sans-serif'],
                'font.sans-serif': ['Arial',
                                    'DejaVu Sans',
                                    'Liberation Sans',
                                    'Bitstream Vera Sans',
                                    'sans-serif'],
                'axes.edgecolor': '.0',
                'axes.labelcolor': '.0',
                'text.color': '.0',
                'xtick.bottom': True,
                'xtick.color': '.0',
                'xtick.direction': 'in',
                'xtick.top': True,
                'xtick.major.size': 3,
                'ytick.color': '.0',
                'ytick.direction': 'in',
                'ytick.left': True,
                'ytick.right': True,
                'ytick.major.size': 3,})

    fig = plt.figure(figsize=(6, 4))
    plt.plot(counts)
    plt.xlabel("Generations (logarithm scale)")
    plt.ylabel("Successfully Updated Frequency")
    plt.xscale("log")
    plt.savefig("./images/tra_by_gen_lvxm.eps")
    plt.clf()
